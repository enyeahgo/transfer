const controllers = {};

controllers.home = (req, res) => {
  res.render('home', {
    title: 'My Military Portfolio',
    name: 'Iñigo Orosco II',
    fullname: 'CPT IÑIGO C OROSCO II (ARM) PA',
    primaryPhoto: 'images/enyeahgo/rmc.png',
    collage: 'images/enyeahgo/collage.jpg'
  });
};

module.exports = controllers;