const router = require('express').Router();
const pageController = require('../controllers/pageController');

// USER PAGES
router.get('/', (req, res) => res.redirect('/home'));
router.get('/home', pageController.home);

module.exports = router;